from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'website/main.html')

def about(request):
    return render(request,'website/About.html')

def schools(request):
    return render(request,'website/schools.html')

def contact(request):
    return render(request,'website/contact.html')

def learningresource(request):
    return render(request,'website/learningresources.html')

def opac(request):
    return render(request,'website/opac.html')

def online_db(request):
    return render(request,'website/online_db.html')

def e_journals(request):
    return render(request,'website/e_journals.html')

def InstM(request):
    return render(request,'website/InstM.html')

def openebooks(request):
    return render(request,'website/openebooks.html')

def membership(request):
    return render(request,'website/membership.html')

def user_files(request):
    return render(request,'website/user_files.html')
