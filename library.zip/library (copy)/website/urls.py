from django.urls import path
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns=[
    path('',views.home,name='web-home'),
    path('about/',views.about,name='web-about'),
    path('schools/',views.schools,name='web-schools'),
    path('contact/',views.contact,name='contact'),
    path('learningresources/',views.learningresource,name='learning-resources'),
    path('opac/',views.opac,name='opac'),
    path('online_db',views.online_db,name="online_db"),
    path('e_journals/',views.e_journals,name="e_journals"),
    path('InstM/',views.InstM,name="InstM"),
    path('openebooks/',views.openebooks,name='openebooks'),
    path('membership/',views.membership,name='membership'),
    path('user_files/',views.user_files,name='user_files'),
]


